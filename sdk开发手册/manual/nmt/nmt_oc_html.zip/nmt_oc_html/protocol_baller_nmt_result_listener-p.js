var protocol_baller_nmt_result_listener_p =
[
    [ "result:", "protocol_baller_nmt_result_listener-p.html#a54029c62934c7bbef63412fb35aaeeed", null ]
];