var searchData=
[
  ['getparameter_316',['getParameter',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#afb05e29ffcca790de4999f059c348149',1,'com::baller::sdk::kws::BallerWakeuper']]],
  ['getwakeuper_317',['getWakeuper',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#acc7e4535e455fcf615980e1908366b4e',1,'com::baller::sdk::kws::BallerWakeuper']]]
];
