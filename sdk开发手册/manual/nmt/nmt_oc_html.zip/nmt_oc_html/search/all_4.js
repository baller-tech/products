var searchData=
[
  ['result_3a_316',['result:',['../protocol_baller_nmt_result_listener-p.html#a54029c62934c7bbef63412fb35aaeeed',1,'BallerNmtResultListener-p']]]
];
