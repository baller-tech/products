var classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r =
[
    [ "get", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#a6652bf2710d71aead2b3ebfb451dc2b2", null ],
    [ "put", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#a357ccb8754f93a4c16d4cb29894721dd", null ],
    [ "sessionBegin", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#a11a71f2ad959fa155b55de79a16ea2e8", null ],
    [ "sessionEnd", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#ae318a3d945ef99e6ea05871cfab8baca", null ],
    [ "version", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#ab6ec9e893e7aec83c27006aad06dccca", null ]
];