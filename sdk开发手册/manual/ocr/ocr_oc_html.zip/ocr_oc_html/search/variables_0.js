var searchData=
[
  ['listener_331',['listener',['../interface_baller_ocr.html#ab671da4caf600a5a91a15a7931e325cb',1,'BallerOcr']]]
];
