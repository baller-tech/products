var searchData=
[
  ['sessionbegin_287',['sessionBegin',['../classcom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s.html#a586de3ac9f9a94f855af5812e524e217',1,'com::baller::sdk::tts::BallerTTS']]],
  ['sessionend_288',['sessionEnd',['../classcom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s.html#ac354728f970413f5addb570810de9ac7',1,'com::baller::sdk::tts::BallerTTS']]],
  ['setworkingthreadnumber_289',['setWorkingThreadNumber',['../classcom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s.html#a36f1d831003722f4c18d624923f33828',1,'com::baller::sdk::tts::BallerTTS']]],
  ['stop_290',['stop',['../classcom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s.html#a440aeaae4c5b1eaafc49898f8d132d60',1,'com::baller::sdk::tts::BallerTTS']]]
];
