var indexSectionsWithContent =
{
  0: "bclmoprsv",
  1: "b",
  2: "c",
  3: "b",
  4: "clmoprsv",
  5: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "文件",
  4: "函数",
  5: "变量"
};

