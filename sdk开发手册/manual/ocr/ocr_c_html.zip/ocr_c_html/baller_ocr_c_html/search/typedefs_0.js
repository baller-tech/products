var searchData=
[
  ['baller_5focr_5fcb_333',['baller_ocr_cb',['../baller__ocr_8h.html#a793515ce290000f63bf8007efca3cd0a',1,'baller_ocr.h']]],
  ['baller_5fsession_5fid_334',['baller_session_id',['../baller__types_8h.html#a670ed74b65cdf44fd56a17d80590d5dd',1,'baller_types.h']]]
];
