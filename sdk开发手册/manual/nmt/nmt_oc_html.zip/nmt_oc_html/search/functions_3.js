var searchData=
[
  ['sessionbegin_3a_329',['sessionBegin:',['../interface_baller_nmt.html#a282ad5e6f6a946d135464c296096b318',1,'BallerNmt']]],
  ['sessionend_330',['sessionEnd',['../interface_baller_nmt.html#ab38c284b533aaf8c935d482cc7290a6a',1,'BallerNmt']]]
];
