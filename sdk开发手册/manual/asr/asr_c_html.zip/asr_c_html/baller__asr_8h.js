var baller__asr_8h =
[
    [ "EBallerASRResultStatus", "baller__asr_8h.html#ae37cc52e3e085566d687237bfbf2cdf4", [
      [ "BALLER_ASR_STATUS_INCOMPLETE", "baller__asr_8h.html#ae37cc52e3e085566d687237bfbf2cdf4a5fe3bbf71618d428a7d4458d9b09cd75", null ],
      [ "BALLER_ASR_STATUS_COMPLETE", "baller__asr_8h.html#ae37cc52e3e085566d687237bfbf2cdf4a86abb73598f1fb06c6e8d2cf23e80118", null ]
    ] ],
    [ "BallerASRAbort", "baller__asr_8h.html#a3e7923235eba4fbf3e0f0b20f03fadae", null ],
    [ "BallerASRGet", "baller__asr_8h.html#a0bde8e1e5e01cad5247d0c15eb59e368", null ],
    [ "BallerASRPut", "baller__asr_8h.html#a7b57bcc6cd13dfcea46792f76db1ced5", null ],
    [ "BallerASRSessionBegin", "baller__asr_8h.html#a9a3ffc024eee57205306f62a093b3281", null ],
    [ "BallerASRSessionEnd", "baller__asr_8h.html#a3a226418e7c848f5654986416801eed2", null ],
    [ "BallerASRVersion", "baller__asr_8h.html#a6adc8c58bd9e0813247a94be9c51aff6", null ]
];