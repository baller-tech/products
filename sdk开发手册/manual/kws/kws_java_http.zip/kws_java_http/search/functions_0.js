var searchData=
[
  ['cleanparameter_313',['cleanParameter',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#a254a6e5da4c8cfbab72df6feb35eecaf',1,'com::baller::sdk::kws::BallerWakeuper']]],
  ['createwakeuper_314',['createWakeuper',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#ab2a38ac17e1b38fafa44cebc22b6908e',1,'com::baller::sdk::kws::BallerWakeuper']]]
];
