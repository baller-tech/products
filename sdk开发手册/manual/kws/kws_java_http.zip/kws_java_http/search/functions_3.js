var searchData=
[
  ['init_318',['init',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#a7f23cfd1ca4dd92bc02cc2a67bb1685d',1,'com::baller::sdk::kws::BallerWakeuper']]],
  ['islistening_319',['isListening',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#abcc4c2f10eebc1ad648a47e9285f84c3',1,'com::baller::sdk::kws::BallerWakeuper']]]
];
