var searchData=
[
  ['sessionbegin_3a_329',['sessionBegin:',['../interface_baller_ocr.html#a5802e5a0fc72875f2db6da174dabe7d5',1,'BallerOcr']]],
  ['sessionend_330',['sessionEnd',['../interface_baller_ocr.html#a8361ad7f8c38e3706e27c5548efe5f62',1,'BallerOcr']]]
];
