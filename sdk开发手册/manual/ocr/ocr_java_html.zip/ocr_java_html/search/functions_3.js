var searchData=
[
  ['put_262',['put',['../classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#a357ccb8754f93a4c16d4cb29894721dd',1,'com::baller::sdk::ocr::BallerOCR']]]
];
