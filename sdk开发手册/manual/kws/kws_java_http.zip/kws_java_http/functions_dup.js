var functions_dup =
[
    [ "b", "functions.html", null ],
    [ "c", "functions_c.html", null ],
    [ "d", "functions_d.html", null ],
    [ "g", "functions_g.html", null ],
    [ "i", "functions_i.html", null ],
    [ "o", "functions_o.html", null ],
    [ "s", "functions_s.html", null ]
];