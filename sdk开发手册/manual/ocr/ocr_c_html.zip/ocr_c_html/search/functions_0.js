var searchData=
[
  ['ballerlogin_260',['BallerLogin',['../baller__common_8h.html#a17ee54dc764fd16d8bc607f3e3879842',1,'baller_common.h']]],
  ['ballerlogout_261',['BallerLogout',['../baller__common_8h.html#af7b36edf18d104921978f9377786796e',1,'baller_common.h']]],
  ['ballerocrget_262',['BallerOCRGet',['../baller__ocr_8h.html#a4bc98cd542346d6ee00d79e983a1633a',1,'baller_ocr.h']]],
  ['ballerocrput_263',['BallerOCRPut',['../baller__ocr_8h.html#a930b6cce70d9086ae8564d24217479ea',1,'baller_ocr.h']]],
  ['ballerocrsessionbegin_264',['BallerOCRSessionBegin',['../baller__ocr_8h.html#ad282c2a9ef5e2a566e36f89e8a326611',1,'baller_ocr.h']]],
  ['ballerocrsessionend_265',['BallerOCRSessionEnd',['../baller__ocr_8h.html#aad11d05dbf42fdc3c071e2ea28743d40',1,'baller_ocr.h']]],
  ['ballerocrversion_266',['BallerOCRVersion',['../baller__ocr_8h.html#a33079e6291af84fd56bdc8fc6453f679',1,'baller_ocr.h']]]
];
