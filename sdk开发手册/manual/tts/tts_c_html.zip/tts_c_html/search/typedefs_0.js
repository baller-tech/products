var searchData=
[
  ['baller_5fsession_5fid_297',['baller_session_id',['../baller__types_8h.html#a670ed74b65cdf44fd56a17d80590d5dd',1,'baller_types.h']]],
  ['baller_5ftts_5fcallback_298',['baller_tts_callback',['../baller__embedded__tts_8h.html#a66b793f8194b30a3a53e8e5fd1a1466d',1,'baller_embedded_tts.h']]]
];
