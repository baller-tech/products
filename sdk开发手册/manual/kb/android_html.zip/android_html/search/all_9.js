var searchData=
[
  ['version_252',['version',['../classcom_1_1baller_1_1sdk_1_1kb_1_1_baller_k_b.html#a037e474e09ca4b7a30b1cf3161c4a34d',1,'com::baller::sdk::kb::BallerKB']]]
];
