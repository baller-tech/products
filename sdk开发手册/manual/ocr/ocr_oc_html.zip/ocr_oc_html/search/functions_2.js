var searchData=
[
  ['result_3a_328',['result:',['../protocol_baller_ocr_result_listener-p.html#a6a27fa0976cd0a8f334666b4f24f4500',1,'BallerOcrResultListener-p']]]
];
