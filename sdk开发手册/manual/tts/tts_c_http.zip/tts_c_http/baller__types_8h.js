var baller__types_8h =
[
    [ "BALLER_API", "baller__types_8h.html#a1b84e4bb66ea2d906fbc8827257f01f6", null ],
    [ "BALLER_CALLBACK", "baller__types_8h.html#ac56de0da681c685fa56e3edc0ab955dc", null ],
    [ "BALLER_INVALID_SESSION_ID", "baller__types_8h.html#a53e4513b9419bb7986834755c81fe875", null ],
    [ "baller_session_id", "baller__types_8h.html#a670ed74b65cdf44fd56a17d80590d5dd", null ]
];