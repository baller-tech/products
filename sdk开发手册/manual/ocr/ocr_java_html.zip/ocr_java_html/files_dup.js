var files_dup =
[
    [ "BallerCommon.java", "_baller_common_8java.html", [
      [ "BallerCommon", "classcom_1_1baller_1_1sdk_1_1common_1_1_baller_common.html", null ]
    ] ],
    [ "BallerErrorCode.java", "_baller_error_code_8java.html", [
      [ "BallerErrorCode", "classcom_1_1baller_1_1sdk_1_1common_1_1_baller_error_code.html", null ]
    ] ],
    [ "BallerOCR.java", "_baller_o_c_r_8java.html", [
      [ "BallerOCR", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r" ]
    ] ],
    [ "BallerOCRResult.java", "_baller_o_c_r_result_8java.html", [
      [ "BallerOCRResult", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r_result.html", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r_result" ]
    ] ]
];