var files_dup =
[
    [ "BallerCommon.java", "_baller_common_8java.html", [
      [ "BallerCommon", "classcom_1_1baller_1_1common_1_1_baller_common.html", null ]
    ] ],
    [ "BallerErrorCode.java", "_baller_error_code_8java.html", [
      [ "BallerErrorCode", "classcom_1_1baller_1_1common_1_1_baller_error_code.html", null ]
    ] ],
    [ "BallerVW.java", "_baller_v_w_8java.html", [
      [ "BallerVW", "classcom_1_1baller_1_1vw_1_1_baller_v_w.html", "classcom_1_1baller_1_1vw_1_1_baller_v_w" ]
    ] ],
    [ "BallerVWProcess.java", "_baller_v_w_process_8java.html", [
      [ "BallerVWProcess", "interfacecom_1_1baller_1_1vw_1_1_baller_v_w_process.html", "interfacecom_1_1baller_1_1vw_1_1_baller_v_w_process" ]
    ] ]
];