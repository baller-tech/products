var protocol_baller_ocr_result_listener_p =
[
    [ "result:", "protocol_baller_ocr_result_listener-p.html#a6a27fa0976cd0a8f334666b4f24f4500", null ]
];