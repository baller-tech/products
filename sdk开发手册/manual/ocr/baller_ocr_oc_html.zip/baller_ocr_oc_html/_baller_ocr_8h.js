var _baller_ocr_8h =
[
    [ "<BallerOcrResultListener>", "protocol_baller_ocr_result_listener-p.html", "protocol_baller_ocr_result_listener-p" ],
    [ "BallerOcr", "interface_baller_ocr.html", "interface_baller_ocr" ]
];