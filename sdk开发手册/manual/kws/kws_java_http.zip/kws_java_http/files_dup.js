var files_dup =
[
    [ "BallerErrorCode.java", "_baller_error_code_8java.html", [
      [ "BallerErrorCode", "classcom_1_1baller_1_1sdk_1_1common_1_1_baller_error_code.html", null ]
    ] ],
    [ "BallerKWSNotify.java", "_baller_k_w_s_notify_8java.html", [
      [ "BallerKWSNotify", "interfacecom_1_1baller_1_1sdk_1_1kws_1_1_baller_k_w_s_notify.html", "interfacecom_1_1baller_1_1sdk_1_1kws_1_1_baller_k_w_s_notify" ]
    ] ],
    [ "BallerWakeuper.java", "_baller_wakeuper_8java.html", [
      [ "BallerWakeuper", "classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html", "classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper" ]
    ] ]
];