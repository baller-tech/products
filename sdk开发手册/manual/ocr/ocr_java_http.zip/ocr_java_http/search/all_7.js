var searchData=
[
  ['version_210',['version',['../classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#ab6ec9e893e7aec83c27006aad06dccca',1,'com::baller::sdk::ocr::BallerOCR']]]
];
