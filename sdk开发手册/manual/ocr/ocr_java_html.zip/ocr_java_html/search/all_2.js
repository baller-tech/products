var searchData=
[
  ['get_236',['get',['../classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html#a6652bf2710d71aead2b3ebfb451dc2b2',1,'com::baller::sdk::ocr::BallerOCR']]]
];
