var baller__embedded__tts_8h =
[
    [ "baller_tts_callback", "baller__embedded__tts_8h.html#a66b793f8194b30a3a53e8e5fd1a1466d", null ],
    [ "BallerTTSAbort", "baller__embedded__tts_8h.html#af88b44833314c265febceaf77d69a65e", null ],
    [ "BallerTTSPut", "baller__embedded__tts_8h.html#a03fc567e90ce8c9acc991f0c053a5288", null ],
    [ "BallerTTSSessionBegin", "baller__embedded__tts_8h.html#a4dc173536c4930ab2b556c0ecab438b5", null ],
    [ "BallerTTSSessionEnd", "baller__embedded__tts_8h.html#a952f068c0fd3147a3b1c5ccd8136550e", null ],
    [ "BallerTTSSetWorkingThreadNumber", "baller__embedded__tts_8h.html#a0b599c367710cef53139d351842ca30c", null ],
    [ "BallerTTSVersion", "baller__embedded__tts_8h.html#abdc4094332524ba70bf328ec183a4e0a", null ],
    [ "BallerTTSWorkingThread", "baller__embedded__tts_8h.html#aeed1ff72e525410d5072320f3cc5789f", null ]
];