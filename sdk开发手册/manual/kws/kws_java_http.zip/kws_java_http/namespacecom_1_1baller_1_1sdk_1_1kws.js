var namespacecom_1_1baller_1_1sdk_1_1kws =
[
    [ "BallerKWSNotify", "interfacecom_1_1baller_1_1sdk_1_1kws_1_1_baller_k_w_s_notify.html", "interfacecom_1_1baller_1_1sdk_1_1kws_1_1_baller_k_w_s_notify" ],
    [ "BallerWakeuper", "classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html", "classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper" ]
];