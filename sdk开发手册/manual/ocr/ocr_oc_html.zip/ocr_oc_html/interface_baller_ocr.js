var interface_baller_ocr =
[
    [ "put:imageData:listener:", "interface_baller_ocr.html#a40d50da134b8e492f601a85dccd36944", null ],
    [ "sessionBegin:", "interface_baller_ocr.html#a5802e5a0fc72875f2db6da174dabe7d5", null ],
    [ "sessionEnd", "interface_baller_ocr.html#a8361ad7f8c38e3706e27c5548efe5f62", null ],
    [ "listener", "interface_baller_ocr.html#ab671da4caf600a5a91a15a7931e325cb", null ]
];