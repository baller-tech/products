var searchData=
[
  ['destroy_315',['destroy',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#a68f98c9d137b3a8e94a41bb75145e1ac',1,'com::baller::sdk::kws::BallerWakeuper']]]
];
