var interfacecom_1_1baller_1_1sdk_1_1kb_1_1_baller_k_b_process =
[
    [ "nextMonosyllable", "interfacecom_1_1baller_1_1sdk_1_1kb_1_1_baller_k_b_process.html#a7dd626d74a62a7090fa25d466d2a703c", null ],
    [ "onProcess", "interfacecom_1_1baller_1_1sdk_1_1kb_1_1_baller_k_b_process.html#a52f11333987ba81877812c9aa26195a9", null ]
];