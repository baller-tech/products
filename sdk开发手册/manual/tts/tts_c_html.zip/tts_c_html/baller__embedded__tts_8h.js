var baller__embedded__tts_8h =
[
    [ "baller_tts_async_callback", "baller__embedded__tts_8h.html#a1ca8ca4e399ab5413eb2b70794ed0686", null ],
    [ "baller_tts_callback", "baller__embedded__tts_8h.html#a66b793f8194b30a3a53e8e5fd1a1466d", null ],
    [ "EBallerTTSStatus", "baller__embedded__tts_8h.html#a9e45501d68a21cc118e8539863ee55df", [
      [ "BALLER_TTS_STATUS_STILL_HAVE_DATE", "baller__embedded__tts_8h.html#a9e45501d68a21cc118e8539863ee55dfa4b8c78556e37d2f6eac653b4aa42e0a9", null ],
      [ "BALLER_TTS_DATA_END", "baller__embedded__tts_8h.html#a9e45501d68a21cc118e8539863ee55dfa339fe227642f3fd198e37667f050f160", null ]
    ] ],
    [ "BallerTTSAbort", "baller__embedded__tts_8h.html#af88b44833314c265febceaf77d69a65e", null ],
    [ "BallerTTSPut", "baller__embedded__tts_8h.html#a03fc567e90ce8c9acc991f0c053a5288", null ],
    [ "BallerTTSPutAsync", "baller__embedded__tts_8h.html#acbeaf408fbe9f66498e233b5268c439c", null ],
    [ "BallerTTSSessionBegin", "baller__embedded__tts_8h.html#a4dc173536c4930ab2b556c0ecab438b5", null ],
    [ "BallerTTSSessionEnd", "baller__embedded__tts_8h.html#a952f068c0fd3147a3b1c5ccd8136550e", null ],
    [ "BallerTTSSetWorkingThreadNumber", "baller__embedded__tts_8h.html#a0b599c367710cef53139d351842ca30c", null ],
    [ "BallerTTSStop", "baller__embedded__tts_8h.html#acd98a036bc09051f19107cb545acf143", null ],
    [ "BallerTTSVersion", "baller__embedded__tts_8h.html#abdc4094332524ba70bf328ec183a4e0a", null ],
    [ "BallerTTSWorkingThread", "baller__embedded__tts_8h.html#aeed1ff72e525410d5072320f3cc5789f", null ]
];