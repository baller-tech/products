var namespacecom_1_1baller_1_1sdk_1_1ocr =
[
    [ "BallerOCR", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r.html", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r" ],
    [ "BallerOCRResult", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r_result.html", "classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r_result" ]
];