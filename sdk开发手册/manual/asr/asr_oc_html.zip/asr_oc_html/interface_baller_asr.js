var interface_baller_asr =
[
    [ "get:status:startTime:endTime:", "interface_baller_asr.html#ace160fad53964e2f8962f3838084c96c", null ],
    [ "put:pcmData:", "interface_baller_asr.html#a6093c1832ddf412de0b1cbe06c3ff0f3", null ],
    [ "sessionBegin:", "interface_baller_asr.html#aad6c4ca116fc492bd55b5a4a04ca90a6", null ],
    [ "sessionEnd", "interface_baller_asr.html#acff89907a55419a75f7a8f35fb386436", null ]
];