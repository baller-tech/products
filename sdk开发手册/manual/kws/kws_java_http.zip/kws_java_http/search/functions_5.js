var searchData=
[
  ['setparameter_321',['setParameter',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#a60d17505654c643fffff123b2a783a76',1,'com::baller::sdk::kws::BallerWakeuper']]],
  ['startlistening_322',['startListening',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#a6f1f59801de7bd78511d584901b01482',1,'com::baller::sdk::kws::BallerWakeuper']]],
  ['stoplistening_323',['stopListening',['../classcom_1_1baller_1_1sdk_1_1kws_1_1_baller_wakeuper.html#a1865523a657ea51f6d08ad13d1536963',1,'com::baller::sdk::kws::BallerWakeuper']]]
];
