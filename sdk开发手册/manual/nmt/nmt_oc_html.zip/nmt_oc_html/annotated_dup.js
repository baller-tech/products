var annotated_dup =
[
    [ "BallerCommon", "interface_baller_common.html", null ],
    [ "BallerNmt", "interface_baller_nmt.html", "interface_baller_nmt" ],
    [ "<BallerNmtResultListener>", "protocol_baller_nmt_result_listener-p.html", "protocol_baller_nmt_result_listener-p" ]
];