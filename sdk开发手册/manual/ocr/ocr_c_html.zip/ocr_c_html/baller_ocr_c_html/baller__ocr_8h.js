var baller__ocr_8h =
[
    [ "baller_ocr_cb", "baller__ocr_8h.html#a793515ce290000f63bf8007efca3cd0a", null ],
    [ "BallerOCRPut", "baller__ocr_8h.html#ab03e3917542ec897cb27a56baf2611c3", null ],
    [ "BallerOCRSessionBegin", "baller__ocr_8h.html#ad282c2a9ef5e2a566e36f89e8a326611", null ],
    [ "BallerOCRSessionEnd", "baller__ocr_8h.html#aad11d05dbf42fdc3c071e2ea28743d40", null ],
    [ "BallerOCRVersion", "baller__ocr_8h.html#a33079e6291af84fd56bdc8fc6453f679", null ]
];