var searchData=
[
  ['ballerocrresult_258',['BallerOCRResult',['../classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r_result.html#a6d6195985bdadf6d8642395ee73a2061',1,'com::baller::sdk::ocr::BallerOCRResult']]]
];
