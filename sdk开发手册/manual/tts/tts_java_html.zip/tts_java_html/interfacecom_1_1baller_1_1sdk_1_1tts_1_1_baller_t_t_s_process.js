var interfacecom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s_process =
[
    [ "onProcess", "interfacecom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s_process.html#ae52cc217c44f9099c473d1129d100b3e", null ]
];