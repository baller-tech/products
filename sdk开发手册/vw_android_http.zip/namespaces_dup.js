var namespaces_dup =
[
    [ "com", "namespacecom.html", "namespacecom" ]
];