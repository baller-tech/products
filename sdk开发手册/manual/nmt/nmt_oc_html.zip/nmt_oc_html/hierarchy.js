var hierarchy =
[
    [ "NSObject", null, [
      [ "BallerCommon", "interface_baller_common.html", null ],
      [ "BallerNmt", "interface_baller_nmt.html", null ]
    ] ],
    [ "<NSObject>", null, [
      [ "<BallerNmtResultListener>", "protocol_baller_nmt_result_listener-p.html", null ]
    ] ]
];