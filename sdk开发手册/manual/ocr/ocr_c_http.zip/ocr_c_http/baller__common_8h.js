var baller__common_8h =
[
    [ "BallerLogin", "baller__common_8h.html#a17ee54dc764fd16d8bc607f3e3879842", null ],
    [ "BallerLogout", "baller__common_8h.html#af7b36edf18d104921978f9377786796e", null ]
];