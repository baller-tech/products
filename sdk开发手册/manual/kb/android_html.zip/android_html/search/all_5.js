var searchData=
[
  ['nextassociationalword_245',['nextAssociationalWord',['../interfacecom_1_1baller_1_1sdk_1_1kb_1_1_baller_k_b_process.html#a77b188299fe985b54f5f90f13610ca9f',1,'com::baller::sdk::kb::BallerKBProcess']]],
  ['nextmonosyllable_246',['nextMonosyllable',['../interfacecom_1_1baller_1_1sdk_1_1kb_1_1_baller_k_b_process.html#a7dd626d74a62a7090fa25d466d2a703c',1,'com::baller::sdk::kb::BallerKBProcess']]]
];
