var baller__ocr_8h =
[
    [ "BallerOCRGet", "baller__ocr_8h.html#a4bc98cd542346d6ee00d79e983a1633a", null ],
    [ "BallerOCRPut", "baller__ocr_8h.html#a930b6cce70d9086ae8564d24217479ea", null ],
    [ "BallerOCRSessionBegin", "baller__ocr_8h.html#ad282c2a9ef5e2a566e36f89e8a326611", null ],
    [ "BallerOCRSessionEnd", "baller__ocr_8h.html#aad11d05dbf42fdc3c071e2ea28743d40", null ],
    [ "BallerOCRVersion", "baller__ocr_8h.html#a33079e6291af84fd56bdc8fc6453f679", null ]
];