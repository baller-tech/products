var indexSectionsWithContent =
{
  0: "beglps",
  1: "b",
  2: "b",
  3: "glps",
  4: "e",
  5: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "文件",
  3: "函数",
  4: "枚举",
  5: "枚举值"
};

