var baller__tts_8h =
[
    [ "BallerTTSGet", "baller__tts_8h.html#a05b9ef34cf9d6baaec906c4c39d071a9", null ],
    [ "BallerTTSPut", "baller__tts_8h.html#a3ace55b3eb29bb34e7ec456f5e7421ff", null ],
    [ "BallerTTSSessionBegin", "baller__tts_8h.html#a4dc173536c4930ab2b556c0ecab438b5", null ],
    [ "BallerTTSSessionEnd", "baller__tts_8h.html#a952f068c0fd3147a3b1c5ccd8136550e", null ],
    [ "BallerTTSVersion", "baller__tts_8h.html#abdc4094332524ba70bf328ec183a4e0a", null ],
    [ "BallerTTSWorkingThread", "baller__tts_8h.html#a07439cf7ddca86de986697dcdcde8e24", null ]
];