var searchData=
[
  ['get_3astatus_3astarttime_3aendtime_3a_322',['get:status:startTime:endTime:',['../interface_baller_asr.html#ace160fad53964e2f8962f3838084c96c',1,'BallerAsr']]]
];
