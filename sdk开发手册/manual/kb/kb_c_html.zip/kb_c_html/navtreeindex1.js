var NAVTREEINDEX1 =
{
"baller__types_8h.html#a670ed74b65cdf44fd56a17d80590d5dd":[0,0,3,3],
"baller__types_8h.html#ac56de0da681c685fa56e3edc0ab955dc":[0,0,3,1],
"baller__types_8h_source.html":[0,0,3],
"files.html":[0,0],
"globals.html":[0,1,0],
"globals.html":[0,1,0,0],
"globals_defs.html":[0,1,5],
"globals_e.html":[0,1,0,1],
"globals_enum.html":[0,1,3],
"globals_eval.html":[0,1,4],
"globals_eval.html":[0,1,4,0],
"globals_func.html":[0,1,1],
"globals_type.html":[0,1,2],
"index.html":[],
"pages.html":[]
};
