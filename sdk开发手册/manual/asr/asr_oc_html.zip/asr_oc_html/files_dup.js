var files_dup =
[
    [ "baller_errors.h", "baller__errors_8h.html", "baller__errors_8h" ],
    [ "BallerAsr.h", "_baller_asr_8h.html", [
      [ "BallerAsr", "interface_baller_asr.html", "interface_baller_asr" ]
    ] ],
    [ "BallerCommon.h", "_baller_common_8h.html", [
      [ "BallerCommon", "interface_baller_common.html", null ]
    ] ]
];