var globals_dup =
[
    [ "b", "globals.html", null ],
    [ "e", "globals_e.html", null ]
];