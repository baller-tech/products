var searchData=
[
  ['mfinish_256',['mFinish',['../classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r_result.html#a9129ad49408c1fe4776429434cbf3d9b',1,'com::baller::sdk::ocr::BallerOCRResult']]],
  ['mresult_257',['mResult',['../classcom_1_1baller_1_1sdk_1_1ocr_1_1_baller_o_c_r_result.html#adc24152a294c4b821d26ef9e7baac1ba',1,'com::baller::sdk::ocr::BallerOCRResult']]]
];
