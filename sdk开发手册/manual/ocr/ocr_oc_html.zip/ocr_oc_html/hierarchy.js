var hierarchy =
[
    [ "<NSObject>", null, [
      [ "BallerCommon", "interface_baller_common.html", null ],
      [ "BallerOcr", "interface_baller_ocr.html", null ],
      [ "<BallerOcrResultListener>", "protocol_baller_ocr_result_listener-p.html", null ]
    ] ]
];