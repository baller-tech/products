var indexSectionsWithContent =
{
  0: "be",
  1: "b",
  2: "b",
  3: "b",
  4: "e",
  5: "b",
  6: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues",
  6: "defines"
};

var indexSectionLabels =
{
  0: "全部",
  1: "文件",
  2: "函数",
  3: "类型定义",
  4: "枚举",
  5: "枚举值",
  6: "宏定义"
};

