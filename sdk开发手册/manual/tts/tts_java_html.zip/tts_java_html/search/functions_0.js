var searchData=
[
  ['abort_299',['abort',['../classcom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s.html#a3aa83f3b983c9964cec2efebbbce7cb1',1,'com::baller::sdk::tts::BallerTTS']]]
];
