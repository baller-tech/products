var searchData=
[
  ['sessionbegin_3a_326',['sessionBegin:',['../interface_baller_asr.html#aad6c4ca116fc492bd55b5a4a04ca90a6',1,'BallerAsr']]],
  ['sessionend_327',['sessionEnd',['../interface_baller_asr.html#acff89907a55419a75f7a8f35fb386436',1,'BallerAsr']]]
];
