/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"首页",url:"index.html"},
{text:"命名空间",url:"namespaces.html",children:[
{text:"命名空间列表",url:"namespaces.html"}]},
{text:"类",url:"annotated.html",children:[
{text:"类列表",url:"annotated.html"},
{text:"类索引",url:"classes.html"},
{text:"类成员",url:"functions.html",children:[
{text:"全部",url:"functions.html",children:[
{text:"b",url:"functions.html#index_b"},
{text:"c",url:"functions_c.html#index_c"},
{text:"l",url:"functions_l.html#index_l"},
{text:"m",url:"functions_m.html#index_m"},
{text:"n",url:"functions_n.html#index_n"},
{text:"o",url:"functions_o.html#index_o"},
{text:"p",url:"functions_p.html#index_p"},
{text:"s",url:"functions_s.html#index_s"},
{text:"v",url:"functions_v.html#index_v"}]},
{text:"函数",url:"functions_func.html"},
{text:"变量",url:"functions_vars.html",children:[
{text:"b",url:"functions_vars.html#index_b"}]}]}]},
{text:"文件",url:"files.html",children:[
{text:"文件列表",url:"files.html"}]}]}
