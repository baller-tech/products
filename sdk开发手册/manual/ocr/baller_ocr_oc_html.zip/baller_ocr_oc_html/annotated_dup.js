var annotated_dup =
[
    [ "BallerCommon", "interface_baller_common.html", null ],
    [ "BallerOcr", "interface_baller_ocr.html", "interface_baller_ocr" ],
    [ "<BallerOcrResultListener>", "protocol_baller_ocr_result_listener-p.html", "protocol_baller_ocr_result_listener-p" ]
];