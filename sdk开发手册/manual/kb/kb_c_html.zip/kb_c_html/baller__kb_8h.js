var baller__kb_8h =
[
    [ "baller_kb_match_callback", "baller__kb_8h.html#ac52a9823491e036945126a6f900fad19", null ],
    [ "baller_kb_syllable_callback", "baller__kb_8h.html#a6d89a74c078360bfaef80064b4a31b37", null ],
    [ "BallerKBCommit", "baller__kb_8h.html#ab4c0a4d1463d502ea36cc35d607524b7", null ],
    [ "BallerKBMore", "baller__kb_8h.html#ad3b1b7cd293762015ad8cb4b7850cdad", null ],
    [ "BallerKBPut", "baller__kb_8h.html#a644b3a242524ac5c2a0d2affdd190f79", null ],
    [ "BallerKBSessionBegin", "baller__kb_8h.html#a7ead7577146b6b616651de16a186679c", null ],
    [ "BallerKBSessionEnd", "baller__kb_8h.html#a076bf56c29f60e33d30e0607642a1370", null ],
    [ "BallerKBSyllable", "baller__kb_8h.html#a70bcef700995d5a10989f7ae792591d2", null ],
    [ "BallerKBVersion", "baller__kb_8h.html#afc0c4d2ec3f69c8d0230dd4357b819bf", null ]
];