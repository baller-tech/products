var searchData=
[
  ['version_318',['version',['../classcom_1_1baller_1_1sdk_1_1tts_1_1_baller_t_t_s.html#a0589159a20752f30f3c6fc4bb774f716',1,'com::baller::sdk::tts::BallerTTS']]]
];
